title: IDEA里面如何快速搜索一个类编译之后的class文件?
date: '2019-12-09 14:21:44'
updated: '2019-12-09 14:21:44'
tags: [Java]
permalink: /articles/2019/12/09/1575872504181.html
---
![](https://img.hacpai.com/bing/20180115.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

![5a3104020001cc6205000408.jpg](https://img.hacpai.com/file/2019/12/5a3104020001cc6205000408-cd0fa0e0.jpg)
适用于在修改某一个类的时候，找到编译后的class文件直接替换到服务器上，不用重新打包、部署。

