title: Spring中bean的三种实例化方式
date: '2019-11-29 17:20:26'
updated: '2019-11-29 17:20:26'
tags: [Spring, Java]
permalink: /articles/2019/11/29/1575019226584.html
---
![](https://img.hacpai.com/bing/20190412.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
    <!-- 配置资源：把对象的创建交给spring来管理 -->
    <bean id="customerService" class="com.service.impl.CustomerServiceImpl"></bean>
    
    <!-- 配置使用静态工厂创建bean对象 -->
    <bean id="staticCustomerService" class="com.factory.StaticFactory" factory-method="getCustomerService"></bean>
	
    <!-- 配置使用实例工厂创建bean对象 -->
    <bean id="instanceFactory" class="com.factory.InstanceFactory"></bean>
    <bean id="instanceCustomerService" factory-bean="instanceFactory" factory-method="getCustomerService"></bean>
```
1. 调用默认无参构造函数创建，默认情况下，如果类中没有默认无参构造函数，则创建失败，会报异常
`在第一种创建方式中，spring会到你所写的class这个类中找到他的无参构造函数，并创建一个对象存在容器里，通过id可以获取到这个对象`

2. 使用工厂中的方法创建对象:需要使用bean标签的factory-method属性，指定静态工厂中创建对象的方法
`第二种方法中多了个工厂类，工厂类中有个**静态**get方法来返回一个class对象，在xml配置的时候用factory-method修饰这个get方法，此时spring会让工程类调用factory-method中指定的方法，并且返回给指定的id这个key存起来`

3. 使用实例工厂的方法创建
`与第二种方法类似，但是这个工厂类的get方法不是静态的，这个时候就要通过bean标签先创建一个工厂类对象，然后用这个工厂类对象调用factory-method中的方法获取到对象`


摘自 [https://blog.csdn.net/bigbigChopper/article/details/85072620](https://blog.csdn.net/bigbigChopper/article/details/85072620)
