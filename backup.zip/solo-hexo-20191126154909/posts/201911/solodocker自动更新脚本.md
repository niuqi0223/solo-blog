title: solo-docker自动更新脚本
date: '2019-11-26 14:17:10'
updated: '2019-11-26 14:17:10'
tags: [Solo]
permalink: /articles/2019/11/26/1574749030345.html
---
![](https://img.hacpai.com/bing/20180801.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

```
#!/bin/bash

#
# Solo docker 更新重启脚本
#
# 1. 请注意修改参数
# 2. 可将该脚本加入 crontab，每日凌晨运行来实现自动更新
#

docker pull b3log/solo
docker stop solo
docker rm solo
docker run --detach --name solo --network=host \
    --env RUNTIME_DB="MYSQL" \
    --env JDBC_USERNAME="root" \
    --env JDBC_PASSWORD="xxxxxx" \
    --env JDBC_DRIVER="com.mysql.cj.jdbc.Driver" \
    --env JDBC_URL="jdbc:mysql://127.0.0.1:3306/solo?useUnicode=yes&characterEncoding=UTF-8&useSSL=false&serverTimezone=UTC" \
    -v /usr/local/src/skins/:/opt/solo/skins/ \
    b3log/solo --listen_port=8088 --server_scheme=https --server_host=www.murmur.xyz

```
